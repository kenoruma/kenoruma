# Kenomotion — iOS editing prototype

Native SwiftUI iOS app, deployment target iOS 17. The interface is designed for a mobile editing workflow.

## Included in this milestone
- Import video from Photos or Files and preview with AVKit.
- Brightness, contrast, and saturation controls are rendered into a single-clip MP4 export and saved to Photos.
- Timeline playhead prototype and editable transform keyframes for position, scale, and rotation.
- Linear, Ease In, Ease Out, and Ease In-Out interpolation for keyframe preview.
- Searchable effects catalogue and project settings panel.
- GitHub Actions workflow to build an unsigned device `.ipa` and app bundle on macOS/Xcode.

## Limitations — read before testing
- Keyframe transforms currently animate the **preview only**; they are not baked into the exported video yet.
- The current timeline represents one imported clip. Multi-layer video/audio compositing, clip trimming, transitions, speed ramping, motion blur, masks, tracking, 3D camera, and most listed effects are not implemented yet.
- The workflow builds an **unsigned** `.ipa`. It is not directly installable until it is signed by a trusted signing method. A successful build has to be confirmed in GitHub Actions; this source has not been compiled in this environment.

## Build from iPhone using GitHub Actions
1. Extract this ZIP in the iPhone Files app.
2. In your GitHub repository, upload the *contents* of `Kenomotion_Native` into the repository root (including the hidden `.github` folder). Do not upload only the outer folder if you want Actions to detect the workflow at `.github/workflows/ios-build.yml`.
3. Commit the upload to `main` or `master`, or open Actions → **Build Kenomotion iOS** → **Run workflow**.
4. Open the completed run and download `Kenomotion-unsigned-iOS-build` under Artifacts.
5. Sign the IPA before installing on a physical iPhone. Never disable device security to install an unknown build.

## Next milestones
1. Bake keyframe transforms into AVFoundation export.
2. Real clip trim handles and duration-based playhead.
3. Multi-layer audio/video composition and transitions.
4. Implement effect renderers one at a time, then speed ramping and motion blur.
