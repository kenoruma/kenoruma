import SwiftUI
import PhotosUI
import AVKit
import UniformTypeIdentifiers

struct FXItem: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let category: String
    let status: FXStatus
}

enum FXStatus: String {
    case native = "Native basic"
    case prototype = "Prototype"
    case planned = "Planned"
}

private let fxLibrary: [FXItem] = [
    FXItem(name: "Brightness / Contrast", category: "Color", status: .native),
    FXItem(name: "Saturation", category: "Color", status: .native),
    FXItem(name: "Black & White", category: "Color", status: .native),
    FXItem(name: "Sepia", category: "Color", status: .native),
    FXItem(name: "Gaussian Blur", category: "Blur", status: .prototype),
    FXItem(name: "Glow", category: "Stylize", status: .prototype),
    FXItem(name: "Sharpen", category: "Blur", status: .prototype),
    FXItem(name: "Vignette", category: "Stylize", status: .prototype),
    FXItem(name: "RGB Split", category: "Glitch", status: .planned),
    FXItem(name: "Digital Glitch", category: "Glitch", status: .planned),
    FXItem(name: "VHS / Scanlines", category: "Glitch", status: .planned),
    FXItem(name: "Film Grain", category: "Cinematic", status: .planned),
    FXItem(name: "Lens Flare", category: "Lighting", status: .planned),
    FXItem(name: "Light Leaks", category: "Lighting", status: .planned),
    FXItem(name: "Turbulent Displace", category: "Distort", status: .planned),
    FXItem(name: "Ripple", category: "Distort", status: .planned),
    FXItem(name: "Kaleidoscope", category: "Distort", status: .planned),
    FXItem(name: "Echo / Trails", category: "Time", status: .planned),
    FXItem(name: "Linear Wipe", category: "Transition", status: .planned),
    FXItem(name: "Audio Spectrum", category: "Audio", status: .planned),
    FXItem(name: "Keying / Chroma Key", category: "Keying", status: .planned),
    FXItem(name: "Mask & Feather", category: "Mask", status: .planned),
    FXItem(name: "Point Tracking", category: "Tracking", status: .planned),
    FXItem(name: "3D Camera / Lights", category: "3D", status: .planned)
]

struct ContentView: View {
    @State private var pickedVideo: PhotosPickerItem?
    @State private var videoURL: URL?
    @State private var player: AVPlayer?
    @State private var selectedTab = "Edit"
    @State private var selectedCategory = "All"
    @State private var selectedFX: FXItem?
    @State private var searchText = ""
    @State private var brightness = 0.0
    @State private var contrast = 1.0
    @State private var saturation = 1.0
    @State private var showFiles = false
    @State private var notice: String?

    private let categories = ["All", "Blur", "Color", "Cinematic", "Distort", "Glitch", "Lighting", "Transition", "Audio", "Mask", "Tracking", "3D"]

    var filteredFX: [FXItem] {
        fxLibrary.filter { (selectedCategory == "All" || $0.category == selectedCategory) && (searchText.isEmpty || $0.name.localizedCaseInsensitiveContains(searchText)) }
    }

    var body: some View {
        VStack(spacing: 0) {
            header
            ScrollView {
                VStack(spacing: 16) {
                    preview
                    transport
                    tabBar
                    if selectedTab == "Edit" { editPanel }
                    else if selectedTab == "Effects" { effectsPanel }
                    else { projectPanel }
                }
                .padding(14)
            }
            .background(Color(red: 0.055, green: 0.06, blue: 0.075))
        }
        .background(Color(red: 0.055, green: 0.06, blue: 0.075))
        .onChange(of: pickedVideo) { _, item in Task { await importVideo(item) } }
        .fileImporter(isPresented: $showFiles, allowedContentTypes: [.movie, .video], allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls): if let url = urls.first { openVideo(url) }
            case .failure(let error): notice = error.localizedDescription
            }
        }
        .alert("Kenomotion", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
            Button("OK", role: .cancel) { notice = nil }
        } message: { Text(notice ?? "") }
    }

    private var header: some View {
        HStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(LinearGradient(colors: [.cyan, .blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                Image(systemName: "waveform.path").font(.system(size: 19, weight: .bold)).foregroundStyle(.white)
            }.frame(width: 38, height: 38)
            VStack(alignment: .leading, spacing: 1) {
                Text("KENOMOTION").font(.system(size: 17, weight: .black, design: .rounded)).tracking(1.1)
                Text("NATIVE VIDEO STUDIO").font(.system(size: 9, weight: .semibold)).tracking(1.6).foregroundStyle(.cyan)
            }
            Spacer()
            PhotosPicker(selection: $pickedVideo, matching: .videos) {
                Image(systemName: "plus.rectangle.on.folder").font(.system(size: 19, weight: .semibold)).frame(width: 42, height: 42).background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
            }
            Button { showFiles = true } label: {
                Image(systemName: "folder").font(.system(size: 18, weight: .semibold)).frame(width: 42, height: 42).background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 12)
        .background(Color(red: 0.08, green: 0.085, blue: 0.105))
    }

    private var preview: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18).fill(Color.black)
            if let player {
                VideoPlayer(player: player).clipShape(RoundedRectangle(cornerRadius: 18))
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "play.rectangle.on.rectangle").font(.system(size: 43, weight: .light)).foregroundStyle(.cyan)
                    Text("Your preview appears here").font(.headline)
                    Text("Import a video from Photos or Files").font(.caption).foregroundStyle(.secondary)
                    PhotosPicker(selection: $pickedVideo, matching: .videos) {
                        Label("Import Video", systemImage: "plus").font(.subheadline.bold()).padding(.horizontal, 16).padding(.vertical, 10).background(.cyan, in: Capsule()).foregroundStyle(.black)
                    }
                }
            }
            VStack {
                HStack {
                    Text("PREVIEW").font(.system(size: 9, weight: .heavy)).tracking(1.5).padding(.horizontal, 9).padding(.vertical, 6).background(.black.opacity(0.6), in: Capsule())
                    Spacer()
                    Text("FIT").font(.system(size: 9, weight: .bold)).padding(.horizontal, 9).padding(.vertical, 6).background(.black.opacity(0.6), in: Capsule())
                }
                Spacer()
            }.padding(12)
        }
        .frame(height: 225)
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.07), lineWidth: 1))
    }

    private var transport: some View {
        HStack {
            Text("00:00:00:00").font(.system(size: 11, weight: .medium, design: .monospaced)).foregroundStyle(.cyan)
            Spacer()
            Button { player?.seek(to: .zero) } label: { Image(systemName: "backward.end.fill") }
            Button { if player?.timeControlStatus == .playing { player?.pause() } else { player?.play() } } label: { Image(systemName: "play.fill").font(.system(size: 15)).foregroundStyle(.black).frame(width: 40, height: 40).background(.cyan, in: Circle()) }
            Button { if let duration = player?.currentItem?.duration { player?.seek(to: duration) } } label: { Image(systemName: "forward.end.fill") }
            Spacer()
            Text("30 FPS").font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundStyle(.secondary)
        }
        .padding(.horizontal, 10).padding(.vertical, 8)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14))
        .buttonStyle(.plain)
    }

    private var tabBar: some View {
        HStack(spacing: 5) {
            tab("Edit", icon: "slider.horizontal.3")
            tab("Effects", icon: "sparkles")
            tab("Project", icon: "square.stack.3d.up")
        }.padding(5).background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14))
    }

    private func tab(_ title: String, icon: String) -> some View {
        Button { selectedTab = title } label: {
            Label(title, systemImage: icon).font(.system(size: 12, weight: .bold)).frame(maxWidth: .infinity).padding(.vertical, 11)
                .foregroundStyle(selectedTab == title ? .black : .secondary)
                .background(selectedTab == title ? Color.cyan : .clear, in: RoundedRectangle(cornerRadius: 10))
        }.buttonStyle(.plain)
    }

    private var editPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionTitle("TIMELINE", detail: "1 layer")
            VStack(alignment: .leading, spacing: 8) {
                HStack { Image(systemName: "film").foregroundStyle(.cyan); Text(videoURL?.lastPathComponent ?? "Video Layer 01").lineLimit(1); Spacer(); Text("V1").font(.caption.bold()).foregroundStyle(.secondary) }
                    .font(.system(size: 12, weight: .medium)).padding(10).background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 8))
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 6).fill(Color.cyan.opacity(0.18))
                        HStack(spacing: 5) { Image(systemName: "film"); Text("VIDEO CLIP").font(.system(size: 9, weight: .heavy)); Spacer() }.foregroundStyle(.cyan).padding(.horizontal, 9)
                    }
                    .frame(width: geo.size.width, height: 35)
                    .overlay(RoundedRectangle(cornerRadius: 6).stroke(.cyan.opacity(0.5), lineWidth: 1))
                }.frame(height: 35)
                Text("Timeline editing and keyframe interpolation are in development.").font(.caption2).foregroundStyle(.secondary)
            }
            sectionTitle("QUICK ADJUSTMENTS", detail: "Preview controls")
            adjustment("Brightness", value: $brightness, range: -1...1)
            adjustment("Contrast", value: $contrast, range: 0.5...2)
            adjustment("Saturation", value: $saturation, range: 0...2)
            HStack {
                Label("Position", systemImage: "move.3d"); Spacer(); Text("0, 0").foregroundStyle(.secondary)
            }.font(.caption).padding(12).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 10))
            HStack {
                Label("Scale", systemImage: "arrow.up.left.and.arrow.down.right"); Spacer(); Text("100%").foregroundStyle(.secondary)
            }.font(.caption).padding(12).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 10))
        }.panelStyle()
    }

    private var effectsPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionTitle("EFFECTS LIBRARY", detail: "\(fxLibrary.count) effects")
            TextField("Search effects", text: $searchText).textFieldStyle(.plain).padding(12).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 10))
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 7) {
                    ForEach(categories, id: \.self) { category in
                        Button { selectedCategory = category } label: {
                            Text(category).font(.caption.bold()).padding(.horizontal, 11).padding(.vertical, 8)
                                .background(selectedCategory == category ? Color.cyan : .white.opacity(0.06), in: Capsule())
                                .foregroundStyle(selectedCategory == category ? .black : .primary)
                        }.buttonStyle(.plain)
                    }
                }
            }
            LazyVStack(spacing: 7) {
                ForEach(filteredFX) { fx in
                    Button { selectedFX = fx } label: {
                        HStack(spacing: 10) {
                            Image(systemName: iconFor(fx.category)).frame(width: 34, height: 34).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 9)).foregroundStyle(.cyan)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(fx.name).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                                Text(fx.category).font(.caption2).foregroundStyle(.secondary)
                            }
                            Spacer()
                            statusPill(fx.status)
                            Image(systemName: "plus.circle").foregroundStyle(.cyan)
                        }.padding(9).background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 12))
                    }.buttonStyle(.plain)
                }
            }
            if let selectedFX {
                VStack(alignment: .leading, spacing: 8) {
                    sectionTitle(selectedFX.name.uppercased(), detail: selectedFX.status.rawValue)
                    Text(description(for: selectedFX)).font(.caption).foregroundStyle(.secondary)
                    if selectedFX.status == .native {
                        Text("This starter includes native Core Image controls for basic color adjustment. Other catalog items are not yet applied to the video render pipeline.").font(.caption2).foregroundStyle(.orange)
                    }
                    Button("Close effect details") { self.selectedFX = nil }.buttonStyle(.bordered)
                }.padding(12).background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 12))
            }
        }.panelStyle()
    }

    private var projectPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionTitle("COMPOSITION", detail: "Project settings")
            settingRow("Resolution", value: "1080 × 1920")
            settingRow("Frame rate", value: "30 FPS")
            settingRow("Duration", value: "From source clip")
            settingRow("Color space", value: "SDR / Rec. 709")
            Divider().overlay(.white.opacity(0.1))
            sectionTitle("ROADMAP", detail: "Not implemented yet")
            ForEach(["Animated keyframes + Graph Editor", "Multi-layer trimming and transitions", "Real-time GPU effects", "Native MP4 export", "Masks, tracking and 3D tools"], id: \.self) { item in
                HStack(alignment: .top, spacing: 9) { Image(systemName: "circle.dashed").foregroundStyle(.orange); Text(item).font(.subheadline); Spacer() }
            }
            Text("Project settings are currently display-only. Export and advanced editing engines still need implementation.").font(.caption).foregroundStyle(.secondary)
        }.panelStyle()
    }

    private func sectionTitle(_ title: String, detail: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.system(size: 11, weight: .black)).tracking(1.2)
            Spacer()
            Text(detail).font(.caption2).foregroundStyle(.secondary)
        }
    }

    private func adjustment(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        VStack(spacing: 6) {
            HStack { Text(title).font(.caption.weight(.medium)); Spacer(); Text(value.wrappedValue, format: .number.precision(.fractionLength(2))).font(.caption.monospacedDigit()).foregroundStyle(.cyan) }
            Slider(value: value, in: range).tint(.cyan)
        }
    }

    private func settingRow(_ title: String, value: String) -> some View {
        HStack { Text(title).font(.subheadline); Spacer(); Text(value).font(.subheadline.monospaced()).foregroundStyle(.cyan) }
            .padding(12).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 10))
    }

    private func statusPill(_ status: FXStatus) -> some View {
        Text(status.rawValue).font(.system(size: 8, weight: .bold)).padding(.horizontal, 7).padding(.vertical, 5)
            .background(status == .native ? Color.green.opacity(0.18) : status == .prototype ? Color.orange.opacity(0.18) : Color.white.opacity(0.07), in: Capsule())
            .foregroundStyle(status == .native ? .green : status == .prototype ? .orange : .secondary)
    }

    private func iconFor(_ category: String) -> String {
        switch category {
        case "Color": return "circle.lefthalf.filled"
        case "Blur": return "drop.halffull"
        case "Glitch": return "waveform.path"
        case "Lighting", "Cinematic": return "sun.max"
        case "Distort": return "water.waves"
        case "Transition": return "arrow.left.arrow.right"
        case "Audio": return "waveform"
        case "Mask": return "scribble.variable"
        case "Tracking": return "scope"
        case "3D": return "cube.transparent"
        default: return "sparkles"
        }
    }

    private func description(for fx: FXItem) -> String {
        switch fx.status {
        case .native: return "Available as a native SwiftUI control in this starter. Full video rendering integration is a next step."
        case .prototype: return "Listed in the interface; the real-time video processing implementation is not complete yet."
        case .planned: return "Catalog placeholder only. A dedicated image/video processing implementation is required."
        }
    }

    @MainActor private func importVideo(_ item: PhotosPickerItem?) async {
        guard let item else { return }
        do {
            if let movie = try await item.loadTransferable(type: ImportedMovie.self) {
                openVideo(movie.url)
            } else { notice = "Could not import this video." }
        } catch { notice = "Import failed: \(error.localizedDescription)" }
    }

    private func openVideo(_ url: URL) {
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }
        do {
            let destination = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Kenomotion-\(UUID().uuidString)-\(url.lastPathComponent)")
            if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
            try FileManager.default.copyItem(at: url, to: destination)
            videoURL = destination
            player = AVPlayer(url: destination)
        } catch { notice = "Could not copy video into app storage: \(error.localizedDescription)" }
    }
}

struct ImportedMovie: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { movie in SentTransferredFile(movie.url) } importing: { received in
            let copy = FileManager.default.temporaryDirectory.appendingPathComponent("import-\(UUID().uuidString)-\(received.file.lastPathComponent)")
            try FileManager.default.copyItem(at: received.file, to: copy)
            return ImportedMovie(url: copy)
        }
    }
}

private extension View {
    func panelStyle() -> some View {
        self.padding(14).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(red: 0.09, green: 0.095, blue: 0.12), in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.06), lineWidth: 1))
    }
}
