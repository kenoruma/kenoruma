# Kenomotion Native iOS Starter

Kenomotion is the renamed native iPhone starter for the video-editor project. It is a SwiftUI iOS app (not a web page or WKWebView wrapper).

## Included in this starter
- SwiftUI dark editing interface branded **KENOMOTION**.
- Import videos from Photos using `PhotosPicker` or from Files using the native file importer.
- Native AVKit video preview and basic playback controls.
- Full-screen editor presentation with status bar and persistent system overlays hidden.
- MP4 export using AVFoundation/Core Image with brightness, contrast, and saturation applied, then save to Photos (requires Photos permission).
- A timeline/layer mockup and composition settings panel.
- Searchable effect catalogue with categories and explicit status labels (`Native basic`, `Prototype`, `Planned`).
- Basic adjustment sliders and roadmap panels.

## Important implementation status
This is an **early native starter**, not a finished After Effects replacement. MP4 export now renders a single imported clip with the brightness, contrast, and saturation controls using AVFoundation/Core Image and saves it to Photos. The timeline remains a visual mockup; trim, multi-layer compositing, keyframes, Graph Editor, audio processing, tracking, masks/rotoscoping, 3D, and most catalog effects are not implemented. Export should still be tested on a real iPhone and may fail for source formats unsupported by the selected export preset.

## Build on a Mac
1. Install Xcode 16 or newer (or a version that supports the selected iOS SDK).
2. Open `Kenomotion.xcodeproj` in Xcode.
3. Select the `Kenomotion` app target and set your own signing team under **Signing & Capabilities**.
4. Choose an iPhone simulator or connect your iPhone, then press **Run**.
5. For a physical iPhone, use your Apple ID/team signing. An `.ipa` cannot be installed directly from this ZIP without compiling and signing it.

Deployment target: iOS 17. No third-party dependencies are required.

## Next engineering steps
1. Add a real timeline data model and clip trimming.
2. Build a Core Image / Metal effect graph and connect controls to the preview.
3. Implement animated keyframes and interpolation.
4. Add AVFoundation composition and export to a user-selected output file.
5. Implement advanced features individually and validate performance on an actual iPhone.
